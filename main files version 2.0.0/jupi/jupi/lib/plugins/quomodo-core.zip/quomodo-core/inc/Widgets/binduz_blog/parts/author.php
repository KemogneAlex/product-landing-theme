
<?php if($settings['show_author'] == 'yes'): ?> 
    <div class="binduz-er-meta-mod binduz-post-author">
        <?php if($settings['show_author_image'] == 'yes'): ?>
            <?php echo get_avatar( get_the_author_meta( 'ID', $post->post_author ), 40 ) ?>
        <?php endif; ?>
        <span>
            <?php if($settings['meta_author_icon']['library'] !=''): ?>
            <?php \Elementor\Icons_Manager::render_icon( $settings['meta_author_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php else: ?>
            <?php \Elementor\Icons_Manager::render_icon( $settings['meta_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php endif; ?>
        </span>
        <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" > <?php echo esc_html(get_the_author()); ?> </a>
    </div>
<?php endif; ?>
