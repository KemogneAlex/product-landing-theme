<?php if($settings['show_post_meta'] == 'yes'): ?>
    <div class="element-ready-post-meta">
        <?php include('category.php');  ?>
        <?php include('author3.php');  ?>
        
        <?php include('date.php');  ?>
        <?php include('comment_meta.php'); ?>

    </div>
<?php endif; ?>