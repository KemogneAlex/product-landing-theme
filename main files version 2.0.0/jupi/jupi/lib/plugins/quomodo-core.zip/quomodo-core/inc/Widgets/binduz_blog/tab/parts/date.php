<?php if($settings['show_post_meta'] == 'yes'): ?>
   
  <?php if($settings['show_date'] =='yes'): ?>    
    
        <div class="binduz-er-meta-date">

                <?php
                    $archive_year  = get_the_time( 'Y',$post->ID ); 
                    $archive_month = get_the_time( 'm',$post->ID ); 
                    $archive_day   = get_the_time( 'd', $post->ID ); 
                ?>
          
                <?php if($settings['meta_date_icon']['library'] !=''): ?>
                  <?php \Elementor\Icons_Manager::render_icon( $settings['meta_date_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php endif; ?>
                
                <a href="<?php echo esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ); ?>">
                  <?php echo esc_html(get_the_date( get_option('date_format') , $post->ID )); ?>
                </a>
        </div>
  
  <?php endif; ?>

<?php endif; ?>