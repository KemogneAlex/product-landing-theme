<?php
namespace Element_Ready_Pro\Widgets\learnpress;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit;
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/common/common.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/position/position.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/style_controls/box/box_style.php' );
require_once( ELEMENT_READY_DIR_PATH . '/inc/content_controls/common.php' );

class Learnpress_Grid_Course extends Widget_Base {

    use \Elementor\Element_Ready_Common_Style;
    use \Elementor\Element_ready_common_content;
    use \Elementor\Element_Ready_Box_Style;

    public $base;

    public function get_name() {
        return 'element-ready-grid-course';
    }

    public function get_title() {
        return esc_html__( 'ER Grid Course', 'element-ready-pro' );
    }

    public function get_icon() { 
        return 'eicon-posts-grid';
    }

   public function get_categories() {
      return [ 'element-ready-pro' ];
   }

  
   public function get_script_depends(){
         
         return [
            'shuffle',
            'element-ready-core',
         ];
   }
   
   public function get_style_depends(){
         
         return [
            'element-ready-grid',
            'element-ready-learnpress'
        ];
   }

    	// Get list courses category
      public function course_category(){

        if(!defined('LP_COURSE_CPT')){
          return [];
        }
        
        $tax_terms = get_terms('course_category', array('hide_empty' => false));
        $category_list = [];
         
        foreach($tax_terms as $term_single) {      
          $category_list[$term_single->term_id] = [$term_single->name];
         
        }
        
        return $category_list;
        }

    protected function register_controls() {
      $this->start_controls_section(
        'content',
        [
          'label' => esc_html__( 'Courses', 'element-ready-pro' )
        ]
      );
  

      $this->add_control(
        'layout',
        [
          'label'   => esc_html__( 'Layout', 'element-ready-pro' ),
          'type'    => Controls_Manager::SELECT,
          'options' => [
            
            'grid-1'         => esc_html__( 'Grid 1', 'element-ready-pro' ),
            'tabs'         => esc_html__( 'Category Tabs', 'element-ready-pro' ),
          ],
          'default' => 'grid-1'
        ]
      );
  
      $this->add_control(
        'order',
        [
          'label'   => esc_html__( 'Order By', 'element-ready-pro' ),
          'type'    => Controls_Manager::SELECT,
          'options' => [
            'popular'  => esc_html__( 'Popular', 'element-ready-pro' ),
            'latest'   => esc_html__( 'Latest', 'element-ready-pro' ),
          ],
          'default' => 'latest',
          'condition' => array(
            'layout' => ['grid-1', 'tabs']
          )
        ]
      );
  
  
  
   
      $this->add_control(
        'limit',
        [
          'label'   => esc_html__( 'Limit Number of Courses', 'element-ready-pro' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 8,
          'min'     => 1,
          'step'    => 1,
          'condition' => array(
            'layout' => ['grid-1', 'tabs']
          )
        ]
      );

      $this->add_control(
        'title_limit',
        [
          'label'   => esc_html__( 'Title Limit', 'element-ready-pro' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 8,
          'min'     => 1,
          'step'    => 1,
          'condition' => array(
            'layout' => ['grid-1', 'tabs']
          )
        ]
      );
  
      $this->add_control(
        'cat_id',
        [
          'label'     => esc_html__( 'Select Category', 'element-ready-pro' ),
          'type'      => Controls_Manager::SELECT2,
          'options'   => $this->course_category(),
          'multiple'    => true,
          'default'     => 'all',
        ]
      );
      $this->add_control(
        'course_list',
        [
          'label'     => esc_html__( 'Select Category', 'element-ready-pro' ),
          'type'      => Controls_Manager::SELECT,
          'options'   => $this->course_list(),
          'condition' => array(
            'layout' => ['grid-single']
          )
        ]
      );

      $this->add_control(
        'featured',
        [
          'label'        => esc_html__( 'Display Featured Courses?', 'element-ready-pro' ),
          'type'         => Controls_Manager::SWITCHER,
          'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
          'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
          'return_value' => 'yes',
          'default'      => '',
          'condition' => array(
            'layout' => ['grid-1', 'tabs']
          )
        ]
      );
  
     
          $this->add_control(
            'course_rating_show',
            [
                'label'        => esc_html__( 'Rating', 'element-ready-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'element-ready-pro' ),
                'label_off'    => esc_html__( 'No', 'element-ready-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition' => array(
                  'layout' => ['grid-1', 'tabs']
                )
            ]
        );

        $this->add_control(
          'lesson_icon',
          [
            'label' => __( 'Lesson Icon', 'element-ready-pro' ),
            'type' => \Elementor\Controls_Manager::ICONS,
            'default' => [
              'value' => 'fas fa-book',
              'library' => 'solid',
            ],
          ]
        );
        
        $this->add_control(
          'student_icon',
          [
            'label' => __( 'Student Icon', 'element-ready-pro' ),
            'type' => \Elementor\Controls_Manager::ICONS,
            'default' => [
              'value' => 'fas fa-user',
              'library' => 'solid',
            ],
          ]
        );


      $this->end_controls_section();

  
      $this->start_controls_section(
        'tab-options',
        [
          'label'     => esc_html__( 'Tab Options', 'element-ready-pro' ),
          'condition' => array(
            'layout' => [ 'tabs' ]
          )
        ]
      );
  
      $this->add_control(
        'limit_tab',
        [
          'label'   => esc_html__( 'Limit Items Per Tab', 'element-ready-pro' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 4,
          'min'     => 1,
          'step'    => 1
        ]
      );
  
      $this->add_control(
        'cat_id_tab',
        [
          'label'       => esc_html__( 'Select Category Tabs', 'element-ready-pro' ),
          'label_block' => true,
          'type'        => Controls_Manager::SELECT2,
          'options'     => $this->course_category(),
          'multiple'    => true,
          'default'     => 'all'
        ]
      );


  
      $this->end_controls_section();

      $this->start_controls_section(
        'tab_menu_style', [
          'label'	 => esc_html__( 'Tab Menu', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          'condition' => ['layout'=> 'tabs']
        ]
      );
      $this->add_control(
        'tab_menu_color', [
          'label'		 => esc_html__( 'color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .shaf-filter li' => 'color: {{VALUE}};',
          ],
        ]
        );

      $this->add_control(
        'tab_menu_active_color', [
          'label'		 => esc_html__( 'Tab menu active color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .shaf-filter li.active' => 'color: {{VALUE}};',
         
          ],
        ]
        );
  
         
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
        'name'		 => 'tab_menu_typography',
        'selector'	 => '{{WRAPPER}} .shaf-filter li',
        ]
        );
        
        $this->add_responsive_control(
          'tab_menu_margin',
          [
            'label' => esc_html__( 'Tab Menu margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
           
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .shaf-filter li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );
        $this->add_responsive_control(
          'tab_menu_padding',
          [
            'label' => esc_html__( 'Tab Menu padding', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .shaf-filter li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );
        $this->add_responsive_control(
          'tab_menu_border_radius',
          [
            'label' => esc_html__( 'Border Radius', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .shaf-filter li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'tab_menu_main_margin',
          [
            'label' => esc_html__( 'Container margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
           
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .shaf-filter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        
        $this->add_responsive_control(
          'content_align', [
            'label'   => esc_html__( 'Alignment', 'element-ready-pro' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
    
                  'left'  => [
                            
                            'title' => esc_html__( 'Left', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-left',
                        
                        ],
                  'center'  => [
                            
                            'title' => esc_html__( 'Center', 'element-ready-pro' ),
                            'icon'  => 'fa fa-align-center',
                        
                        ],
                  'right'	 => [
          
                      'title' => esc_html__( 'Right', 'element-ready-pro' ),
                      'icon'  => 'fa fa-align-right',
                            
                    ],
                  'justify'	 => [
          
                      'title' => esc_html__( 'Justified', 'element-ready-pro' ),
                      'icon'  => 'fa fa-align-justify',
                            
                    ],
                  ],
                  'default' => 'right',
                      
                  'selectors' => [
                    '{{WRAPPER}} .shaf-filter' => 'text-align: {{VALUE}};',
                  ],
            ]
        );//Responsive control end

 
      $this->end_controls_section();

     

      $this->start_controls_section(
        'title_style', [
          'label'	 => esc_html__( 'Course Title', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          'title_color', [
            'label'		 => esc_html__( 'Title color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .title a' => 'color: {{VALUE}};',
              '{{WRAPPER}} .flipper .front .title' => 'color: {{VALUE}};',
            ],
          ]
        );

        $this->add_control(
          'title_hover_color', [
            'label'		 => esc_html__( 'Title hover color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item:hover .title a' => 'color: {{VALUE}};',
              '{{WRAPPER}} .flipper:hover .title a' => 'color: {{VALUE}};',
            ],
          ]
        );
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'title_typography',
          'selector'	 => '{{WRAPPER}} .element-ready-lp-grid-course-item .title a, {{WRAPPER}} .flipper .title a,{{WRAPPER}} .flipper .title',
          ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
            'name'		 => 'title_hover_typography',
            'label'		 => esc_html__( 'Title hover', 'element-ready-pro' ),
            'selector'	 => '{{WRAPPER}} .flipper .back .title a',
            'condition' => array(
              'layout' => ['tabs']
            ),
            ]
          );
        
        $this->add_responsive_control(
          'title_margin',
          [
            'label' => esc_html__( 'Title margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .flipper .front .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'title_back_margin',
          [
            'label' => esc_html__( 'Title Hover Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'condition' => array(
              'layout' => ['tabs']
            ),
            'selectors' => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .flipper .back .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        
      
      $this->end_controls_section();

      $this->start_controls_section(
        'category_meta_style', [
          'label'	 => esc_html__( 'Category', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          '_category_meta_color', [
            'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .c-cate' => 'color: {{VALUE}};',
              '{{WRAPPER}} .front .c-cate' => 'color: {{VALUE}};',
            
            ],
          ]
        );

        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'category_meta_typography',
          'selector'	 => '{{WRAPPER}} .element-ready-lp-grid-course-item .c-cate,{{WRAPPER}} .front .c-cate',
          ]
        );  

        $this->add_control(
          'category_hover_color', [
            'label'		 => esc_html__( 'Hover Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .c-cate:hover' => 'color: {{VALUE}};',
              '{{WRAPPER}} .back .c-cate' => 'color: {{VALUE}};',
            
            ],
          ]
        );

        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'category__back_meta_typography',
          'label'		 => esc_html__( 'Hover Typhography', 'element-ready-pro' ),
          'selector'	 => '{{WRAPPER}} .back .c-cate',
          'condition' => array(
            'layout' => ['tabs']
          ),
          ]
        );  

        $this->add_responsive_control(
          'cats_bordr_r_radious',
          [
             'label'      => esc_html__( 'Border Radious', 'element-ready-pro' ),
             'type'       => Controls_Manager::SLIDER,
             'size_units' => [ 'px' ,'%' ],
             'range'      => [
                'px' => [
                   'min'  => 0,
                   'max'  => 800,
                   'step' => 1,
                ],
             
             ],
          
             'selectors' => [
                '{{WRAPPER}} .element-ready-grid-course-c-cat' => 'border-radius: {{SIZE}}{{UNIT}};',
             ],
          ]
       );
  
        $this->add_control(
          'categhory_bg_color', [
            'label'		 => esc_html__( 'Background color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .c-cate' => 'background-color: {{VALUE}};',
              '{{WRAPPER}} .front .c-cate' => 'background-color: {{VALUE}};',
             
            ],
          ]
          );

          $this->add_control(
            'categhory_hover_bg_color', [
              'label'		 => esc_html__( 'Hover Background', 'element-ready-pro' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .element-ready-lp-grid-course-item .c-cate:hover' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .back .c-cate' => 'background-color: {{VALUE}};',
                
              ],
            ]
          ); 
          
          $this->add_responsive_control(
            'category_margin',
            [
              'label' => esc_html__( 'Margin', 'element-ready-pro' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .element-ready-lp-grid-course-item .c-cate' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front .c-cate' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_responsive_control(
            'category_padding',
            [
              'label' => esc_html__( 'Padding', 'element-ready-pro' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .element-ready-lp-grid-course-item .c-cate' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front .c-cate' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

      $this->end_controls_section();

      $this->start_controls_section(
        'lesson_meta_style', [
          'label'	 => esc_html__( 'Lesson', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );
      $this->add_control(
        'lesson_meta_color', [
          'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-lesson' => 'color: {{VALUE}};',
            '{{WRAPPER}} .front .fcf-bottom .element-ready-lp-lesson' => 'color: {{VALUE}};',
           
          ],
        ]
      );

    

      $this->add_control(
        'lesson_hover_color', [
          'label'		 => esc_html__( 'Hover Color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-lesson:hover' => 'color: {{VALUE}};',
            '{{WRAPPER}} .back .fcf-bottom .element-ready-lp-lesson' => 'color: {{VALUE}};',
           
          ],
        ]
        );
  
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'lesson_meta_typography',
          'selector'	 => '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-lesson,{{WRAPPER}} .element-ready-lp-lesson',
          ]
        );

        $this->add_control(
          'lesson_icon_meta_color', [
            'label'		 => esc_html__( 'Icon Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-lesson i' => 'color: {{VALUE}};',
              '{{WRAPPER}} .fcf-bottom .element-ready-lp-lesson i' => 'color: {{VALUE}};',
             
            ],
          ]
        );
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'lesson_icon_meta_typography',
          'selector'	 => '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-lesson i,{{WRAPPER}} .fcf-bottom .element-ready-lp-lesson i',
          ]
        );

        $this->add_responsive_control(
          'lesson_margin',
          [
            'label' => esc_html__( 'Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-lesson' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .fcf-bottom .element-ready-lp-lesson' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'lesson_padding',
          [
            'label' => esc_html__( 'Padding', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-lesson' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .fcf-bottom .element-ready-lp-lesson' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

      $this->end_controls_section();

      $this->start_controls_section(
        'students_meta_style', [
          'label'	 => esc_html__( 'Students', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

      $this->add_control(
        'students_meta_color', [
          'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-students' => 'color: {{VALUE}};',
            '{{WRAPPER}} .front .fcf-bottom .element-ready-lp-students' => 'color: {{VALUE}};',
           
          ],
        ]
      );

      $this->add_control(
        'students_hover_color', [
          'label'		 => esc_html__( 'Hover Color', 'element-ready-pro' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-students:hover' => 'color: {{VALUE}};',
            '{{WRAPPER}} .back .fcf-bottom .element-ready-lp-students' => 'color: {{VALUE}};',
           
          ],
        ]
        );
  
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'students_meta_typography',
          'selector'	 => '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-students,{{WRAPPER}} .fcf-bottom .element-ready-lp-students',
          ]
        );

        $this->add_control(
          'students_icon_meta_color', [
            'label'		 => esc_html__( 'Icon Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-students i' => 'color: {{VALUE}};',
              '{{WRAPPER}} .fcf-bottom .element-ready-lp-students i' => 'color: {{VALUE}};',
             
            ],
          ]
        );
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'students_icon_meta_typography',
          'selector'	 => '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-students i,{{WRAPPER}} .fcf-bottom .element-ready-lp-students i',
          ]
        );

        $this->add_responsive_control(
          'students_margin',
          [
            'label' => esc_html__( 'Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-students' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .fcf-bottom .element-ready-lp-students' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'students_padding',
          [
            'label' => esc_html__( 'Padding', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item .element-ready-lp-students' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .fcf-bottom .element-ready-lp-students' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

      $this->end_controls_section();

      $this->text_css(
          array(
            'title' => esc_html__('Regular Price','element-ready-pro'),
            'slug' => 'lp_price__style',
            'element_name' => 'lp_price_element_ready_',
            'selector' => '{{WRAPPER}} .element-ready-lp-price span',
          )
      );
      $this->text_css(
        array(
          'title' => esc_html__('Discount Price','element-ready-pro'),
          'slug' => 'lp_discount_price__style',
          'element_name' => 'lp_discount_price_element_ready_',
          'selector' => '{{WRAPPER}} .element-ready-lp-price',
        )
    );
     
      $this->start_controls_section(
        'instructor_style', [
          'label'	 => esc_html__( 'Instructor', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          'instructor_color', [
            'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .author a' => 'color: {{VALUE}};',
            ],
          ]
        );
  
         
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
        'name'		 => 'instructor_title_typography',
        'selector'	 => '{{WRAPPER}} .author a',
        ]
        );

        $this->add_responsive_control(
          'instructor_margin',
          [
            'label' => esc_html__( 'Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'instructor_padding',
          [
            'label' => esc_html__( 'Padding', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'instructor_name_margin',
          [
            'label' => esc_html__( 'Name Margin', 'element-ready-pro' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );


      $this->end_controls_section();

      $this->start_controls_section(
        'course_rating', [
          'label'	 => esc_html__( 'Course Rating', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          
        ]
      );

         
          $this->add_control(
            'course_rating_color_', [
              'label'		 => esc_html__( 'Color', 'element-ready-pro' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ratings i' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_control(
            'course_rating_active_color_', [
              'label'		 => esc_html__( 'Active Color', 'element-ready-pro' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ratings .active' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_group_control(
            Group_Control_Typography::get_type(), [
            'name'		 => 'instructor_cpourse_rating___typography',
            'selector'	 => '{{WRAPPER}} .ratings i',
            ]
            );

          $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
              'name'     => 'course_Rating_border_',
              'label'    => esc_html__( 'Top Border', 'element-ready-pro' ),
              'selector' => '{{WRAPPER}} .ratings',
            ]
          );

          $this->add_responsive_control(
            'course_rating_margin',
            [
              'label'      => esc_html__( 'Margin', 'element-ready-pro' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors'  => [
                '{{WRAPPER}} .ratings' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_responsive_control(
            'course_rating_padding',
            [
              'label' => esc_html__( 'Padding', 'element-ready-pro' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .ratings' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

      $this->end_controls_section();

      $this->text_css(
        array(
           'title' => esc_html__('Rating Text','element-ready-pro'),
           'slug' => 'rating_title__style',
           'element_name' => 'rating_title_element_ready_',
           'selector' => '{{WRAPPER}} .element-ready-lp-ratings span',
        )
    );

    $this->box_css(
      array(
         'title' => esc_html__('Grid Wrapper','element-ready-pro'),
         'slug' => 'lp_course_wrapper_box_style',
         'element_name' => 'lp_course_wrapper_eready_',
         'selector' => '{{WRAPPER}} .element-ready-lp-grid-course-wrapper',
      )
     );
      
      $this->start_controls_section(
        'course_single_box', [
          'label'	 => esc_html__( 'Single Box', 'element-ready-pro' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          
        ]
      );

      $this->add_responsive_control(
        'single_item_width',
        [
           'label'      => esc_html__( 'Width', 'element-ready-pro' ),
           'type'       => Controls_Manager::SLIDER,
           'size_units' => [ 'px' ,'%'],
           'range'      => [
              'px' => [
                 'min'  => 0,
                 'max'  => 2000,
                 'step' => 1,
              ],
            
           ],
          
           'selectors' => [
              '{{WRAPPER}} .element-ready-lp-grid-course-item' => 'width: {{SIZE}}{{UNIT}};',
              '{{WRAPPER}} .element-ready-feature-course-item' => 'width: {{SIZE}}{{UNIT}};',
           ],
        ]
     );

     $this->add_responsive_control(
      'single_item_nin_width',
      [
         'label'      => esc_html__( 'Min Width', 'element-ready-pro' ),
         'type'       => Controls_Manager::SLIDER,
         'size_units' => [ 'px','%' ],
         'range'      => [
            'px' => [
               'min'  => 0,
               'max'  => 2000,
               'step' => 5,
            ],
          
         ],
        
         'selectors' => [
            '{{WRAPPER}} .element-ready-lp-grid-course-item' => 'min-width: {{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .element-ready-feature-course-item' => 'min-width: {{SIZE}}{{UNIT}};',
         ],
      ]
   );



      $this->add_group_control(
        \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'single_box_item_background',
                'label'    => esc_html__( 'Background', 'element-ready-pro' ),
                'types'    => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .element-ready-lp-grid-course-item,{{WRAPPER}} .front',
            ]
       );

       $this->add_group_control(
        \Elementor\Group_Control_Border::get_type(),
        [
          'name' => 'course_single_item_border_',
          'label' => esc_html__( 'Border', 'element-ready-pro' ),
          'selector' => '{{WRAPPER}} .element-ready-lp-grid-course-item,{{WRAPPER}} .front',
        ]
      );
  
       $this->add_responsive_control(
        '_item__box_border_radius',
        [
            'label'     => esc_html__( 'Border Radius', 'element-ready-pro' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'selectors' => [
                '{{WRAPPER}} .element-ready-lp-grid-course-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .back' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
                
            ],
            'separator' => 'before',
        ]
      );

      $this->add_control(
        'single_border2_popover_toggle',
        [
            'label' => esc_html__( 'Hover Border', 'element-ready-pro' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'label_off' => esc_html__( 'Default', 'element-ready-pro' ),
            'label_on' => __( 'Over Top Color', 'element-ready-pro' ),
            'return_value' => 'yes',
            'default' => 'yes',
            'condition' => array(
              'layout' => ['grid-1']
            )
            
        ]
    );

    $this->start_popover();
        $this->add_control(
            'item_border_top_border', [

                'label'     => esc_html__( 'Color', 'element-ready-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  '{{WRAPPER}} .element-ready-lp-grid-course-item:hover' => 'box-shadow: 0px -3px 0px 0px {{VALUE}};',
                  '{{WRAPPER}} .element-ready-feature-course-item:hover' => 'box-shadow: 0px -3px 0px 0px {{VALUE}};',
            
                ],
            ]
        );

          $this->add_group_control(
              \Elementor\Group_Control_Box_Shadow::get_type(),
              [
                  'name' => 'item_border_top_box_hover_shadow',
                  'label' => esc_html__( 'Box Shadow', 'element-ready-pro' ),
                  'selector' => '{{WRAPPER}} .element-ready-lp-grid-course-item:hover,{{WRAPPER}} .element-ready-feature-course-item:hover',
              ]
          );

          $this->end_popover();

          $this->add_group_control(
              \Elementor\Group_Control_Box_Shadow::get_type(),
              [
                  'name' => 'item_border_top_box_shadow',
                  'label' => esc_html__( 'Box Shadow', 'element-ready-pro' ),
                  'selector' => '{{WRAPPER}} .element-ready-lp-grid-course-item,{{WRAPPER}} .front',
                
              ]
          );

          $this->add_responsive_control(
            'single_item_box_padding',
            [
              'label' => esc_html__( 'Padding', 'element-ready-pro' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .element-ready-lp-grid-course-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .back' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_responsive_control(
            'single_item_box_margin',
            [
              'label' => esc_html__( 'Margin', 'element-ready-pro' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .element-ready-lp-grid-course-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .back' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_control(
            'single_item_',
            [
              'label' => esc_html__( 'Hover Background', 'element-ready-pro' ),
              'type' => \Elementor\Controls_Manager::HEADING,
              'separator' => 'before',
            ]
          );

          $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'single_hover_box_item_background',
                    'label'    => esc_html__( 'Hover Background', 'element-ready-pro' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .element-ready-lp-grid-course-item:hover,{{WRAPPER}} .back',
                ]
           );


      $this->end_controls_section();
 
     
    }    
    protected function render() {
   
      $settings   = $this->get_settings();

      $course_settings = array(
       
        'order'             => $settings['order'],
        'cat_id'            => $settings['cat_id'],
        'course_list'       => $settings['course_list'],
        'layout'            => $settings['layout'],
        'limit'             => $settings['limit'],
        'tabs-options'      => array(
          'limit_tab'  => $settings['limit_tab'],
          'cat_id_tab' => $settings['cat_id_tab']
        ),
        'featured'          => $settings['featured'],
        'all_category' => $this->course_category()
      );

      $category_groups = []; 

      if(defined('LP_COURSE_CPT')){

         global $post, $wpdb;
         $random    = rand( 1, 99 );
         $limit_tab = $course_settings['tabs-options']['limit_tab'] ? $course_settings['tabs-options']['limit_tab'] : 4;
         $cat_id    = $course_settings['cat_id'] ? $course_settings['cat_id'] : array();
         $limit     = $course_settings['limit'];
         $featured  = ! empty( $course_settings['featured'] ) ? true : false;
         $sort      = $course_settings['order'];
         $thumb_w   = ( ! empty( $course_settings['thumbnail_width'] ) && '' != $course_settings['thumbnail_width'] ) ? $course_settings['thumbnail_width'] : apply_filters( 'thim_course_thumbnail_width', 450 );
         $thumb_h   = ( ! empty( $course_settings['thumbnail_height'] ) && '' != $course_settings['thumbnail_height'] ) ? $course_settings['thumbnail_height'] : apply_filters( 'thim_course_thumbnail_height', 400 );
         $cat_id_tab = $course_settings['tabs-options']['cat_id_tab'] ? $course_settings['tabs-options']['cat_id_tab'] : array();

         $condition = array(
            'post_type'           => 'lp_course',
            'posts_per_page'      => $limit,
            
         );

         if ( is_array($cat_id) && count($cat_id) ) {

               $condition['tax_query'] = array(
                  array(
                     'taxonomy' => 'course_category',
                     'field'    => 'term_id',
                     'terms'    => $cat_id
                  ),
               );
            
         }

         if ( $sort == 'popular' ) {
            global $wpdb;
            $query = $wpdb->prepare( "
            SELECT ID, a+IF(b IS NULL, 0, b) AS students FROM(
               SELECT p.ID as ID, IF(pm.meta_value, pm.meta_value, 0) as a, (
                     SELECT COUNT(*)
                  FROM (SELECT COUNT(item_id), item_id, user_id FROM {$wpdb->prefix}learnpress_user_items GROUP BY item_id, user_id) AS Y
                  GROUP BY item_id
                  HAVING item_id = p.ID
                  ) AS b
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} AS pm ON p.ID = pm.post_id  AND pm.meta_key = %s
                  WHERE p.post_type = %s AND p.post_status = %s
                  GROUP BY ID
                  ) AS Z
                  ORDER BY students DESC
                     LIMIT 0, $limit
                  ", '_lp_students', 'lp_course', 'publish' );

            $post_in = $wpdb->get_col( $query );

            $condition['post__in'] = $post_in;
            $condition['orderby']  = 'post__in';
         }

         if( $featured ) {
            $condition['meta_query'] = array(
               array(
                  'key' => '_lp_featured',
                  'value' =>  'yes',
               )
            );
         }

         $the_query = new \WP_Query( $condition );


       ?>
        <?php if ( $the_query->have_posts() ) : ?>
            <?php if($settings['layout'] =='grid-1'): ?>  
                <div  data-layout="<?php echo esc_attr($settings['layout']); ?>"  class="element-ready-lp-grid-course-wrapper widget-layout">
                    <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                      <?php

                            $terms         = get_the_terms( $post->ID, 'course_category' );
                            $cat           = '';
                            $cat_with_link = '';
                          
                            if(is_array($terms)):
            
                              foreach($terms as $tkey=>$term):
                                $cat.= $term->slug.' ';
                              endforeach;
            
                            endif; 
                            
                            $cat_with_link     = element_ready_lp_course_cageory_by_id($post->ID);
                            $course            = LP()->global['course'];
                            $lessons           = $course->get_curriculum_items( 'lp_lesson' )?count( $course->get_curriculum_items( 'lp_lesson' ) ) : 0;
                            $students_enrolled = $course->get_users_enrolled();
                            $instructor        = $course->get_instructor();
                            $instructor_link   = $course->get_instructor_html();
                            $instructor_id     = $course->get_id();
                            $meta              = get_post_meta( $post->ID );
                                        
                            $featured = isset($meta['_lp_featured'][0]) ? $meta['_lp_featured'][0] : '';
                           
                      ?>
                     
                        <div class="element-ready-lp-grid-course-item">
                              
                              <?php 
                                  echo wp_kses_post($cat_with_link);
                              ?>
                              <h4 class="title element-ready-course-title"><a href="<?php echo esc_url($course->get_permalink()); ?>"> <?php echo wp_trim_words(  get_the_title(), $settings['title_limit'],'' ); ?> </a></h4>
                              <div class="fcf-bottom element-ready-course-bottom">
                                  <a class="element-ready-lp-lesson" href="<?php echo esc_url($course->get_permalink()); ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['lesson_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo esc_html($lessons); ?> <?php echo esc_html__('Lessons','element-ready-pro'); ?></a>
                                  <a class="element-ready-lp-students" href="<?php echo esc_url($course->get_permalink()); ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['student_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo esc_html($students_enrolled); ?> </a>
                              </div>
                              <?php if(has_post_thumbnail()): ?>
                                  <div class="fcf-thumb element-ready-lp-thumb">
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_id(),'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                  </div>
                              <?php endif; ?>
                              <div class="hover-course element-ready-lp-course">
                                  <div class="course-price element-ready-lp-price element-ready-lp-price ">
                                      <?php if($course->is_free()): ?>
                                          <?php echo esc_html__('free','element-ready-pro'); ?>
                                      <?php else: ?>
                                          
                                          <?php if( $course->has_sale_price() ): ?> 
                                            <?php echo $course->get_price_html(); ?> 
                                          <?php endif; ?>
                                          <span> <?php echo $course->get_origin_price_html(); ?> </span>   

                                      <?php endif; ?>
                                    
                                  </div>
                                  <?php 
                                      $dir          = learn_press_user_profile_picture_upload_dir();
                                      $user         = get_user_by( 'id', $instructor->get_id());
                                      $pro_link     = get_user_meta($user->ID,'_lp_profile_picture',true);
                                      $base_url     = isset($dir['baseurl'])?$dir['baseurl']:'';
                                      $profile_link = $base_url.'/'.$pro_link;
        
                                  ?>
                                  <div class="author element-ready-lp-author">
                                    <img src="<?php echo esc_url( get_avatar_url( $instructor->get_id() ) ); ?>">
                                    <?php  echo wp_kses_post($instructor_link) ?>
                                  </div>
                                  <?php if( function_exists( 'learn_press_get_course_rate' ) && $settings['course_rating_show'] =='yes' ): ?>
                                        <?php
                                            $course_rate_res = learn_press_get_course_rate( $post->ID, false );
                                            $course_rate     = $course_rate_res['rated'];
                                            $total           = $course_rate_res['total'];

                                            $percent = ( ! $course_rate ) ? 0 : min( 100, ( round( $course_rate * 2 ) / 2 ) * 20 );
                                        
                                        ?>
                                        <div class="ratings element-ready-lp-ratings">
                                        <?php foreach (range(1, 5) as $hnumber): ?>
                                                        <i class="fa fa-star <?php echo esc_attr($hnumber<=$course_rate?'active':'inactive'); ?>"></i>
                                                      <?php endforeach; ?>
                                          <span><?php echo $percent; ?> (<?php echo sprintf( __( '%s Reviews', 'element-ready-pro' ), $course_rate ); ?>)</span>
                                        
                                        </div>
                                  <?php endif; ?>
                            
                              </div>
                      </div>
                  <?php endwhile; wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>
            <?php if($settings['layout'] =='tabs'): ?> 
              
                <!-- Feature Course Start -->
                <section data-layout="<?php echo esc_attr($settings['layout']); ?>" class="feature-course-section widget-layout">
                   
                    
                            <div class="element-ready-filter-nav">
                                <ul class="shaf-filter shaf-filter-<?php echo esc_attr($this->get_id()); ?> element-ready-shaf-filter">
                                    <li class="active" data-group="all"><?php echo esc_html__( 'All','element-ready-pro' ); ?></li>
                                   
                                    <?php	
                                          foreach((array)$cat_id_tab as $key=> $tacat_id):
                                            if($key==$limit_tab){
                                              break;
                                            }

                                          $category =  get_term($tacat_id);
                                       
                                        ?>
                                        <?php if(is_object($category) && isset($category->name) ): ?>
                                            <li data-group="<?php echo esc_attr($category->slug); ?>"><?php echo esc_html($category->name); ?> </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                     
                        <div class="shafull-container shafull-container-<?php echo esc_attr($this->get_id()); ?> quomodo-row element-ready-tab-course-wrapper">
                             
                              <?php

                                  while ( $the_query->have_posts() ) : $the_query->the_post();

                                      $category_groups      = [];
                                      $terms                = get_the_terms( $post->ID, 'course_category' );
                                      $cat                  = '';
                                      $cat_with_link        = '';
                                      $single_category_name = '';
                                  
                                      if(is_array($terms)):

                                        foreach($terms as $tkey=>$term):
                                          $cat.= $term->slug.' ';
                                          $category_groups[] = $term->slug;
                                          $single_category_name =  $term->name;
                                        endforeach;

                                      endif; 

                                      $cat_with_link     = element_ready_lp_course_cageory_by_id($post->ID);
                                      $course            = LP()->global['course'];
                                      $lessons           = $course->get_curriculum_items( 'lp_lesson' )? count( $course->get_curriculum_items( 'lp_lesson' ) ) : 0;
                                      $students_enrolled = $course->get_users_enrolled();
                                      $instructor        = $course->get_instructor();
                                      $instructor_link   = $course->get_instructor_html();
                                      $instructor_id     = $course->get_id();
                                      $meta              = get_post_meta( $post->ID );
                                      $featured          = isset($meta['_lp_featured'][0]) ? $meta['_lp_featured'][0] : '';
                                      
                                     
                                          
                              ?>

                                <div class="shaf-item shaf-item-<?php echo esc_attr($this->get_id()); ?> element-ready-course-shaf-item quomodo-col-lg-4 quomodo-col-md-6" data-groups='<?php echo json_encode($category_groups); ?>'>
                                    <div class="element-ready-feature-course-item">
                                        <div class="flipper">
                                            <div class="front">
                                                <?php if(has_post_thumbnail()): ?>
                                                    <div class="fcf-thumb">
                                                        <img src="<?php echo esc_url( get_the_post_thumbnail_url( get_the_id(), 'full' ) ); ?>" alt="<?php echo esc_attr( the_title_attribute() ); ?>">
                                                    </div>
                                                <?php endif; ?>
                                                <p class="c-cate"> <?php echo esc_html($single_category_name); ?> </p>
                                                <h4 class="title"> <?php echo wp_trim_words(  get_the_title(), $settings['title_limit'] ); ?> </h4>
                                                <div class="fcf-bottom">
                                                    <a class="element-ready-lp-lesson" href="<?php echo esc_url($course->get_permalink()); ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['lesson_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo esc_html($lessons); ?> <?php echo esc_html__('Lessons','element-ready-pro'); ?></a>
                                                    <a class="element-ready-lp-students" href="<?php echo esc_url($course->get_permalink()); ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['student_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo esc_html($students_enrolled); ?></a>
                                                </div>
                                            </div>
                                            <div class="back">
                                                <?php if(has_post_thumbnail()): ?>
                                                    <div class="fcf-thumb">
                                                        <img src="<?php echo esc_url( get_the_post_thumbnail_url( get_the_id(), 'full' ) ); ?>" alt="<?php echo esc_attr( the_title_attribute() ); ?>">
                                                    </div>
                                                <?php endif; ?>
                                             
                                                  <?php 
                                                      echo wp_kses_post($cat_with_link);
                                                  ?>
                                              
                                                <h4 class="title"><a href="<?php echo esc_url($course->get_permalink()); ?>"><?php echo wp_trim_words(  get_the_title(), $settings['title_limit'] ); ?></a></h4>
                                                <?php if( function_exists( 'learn_press_get_course_rate' ) && $settings['course_rating_show'] =='yes' ): ?>
                                                      <?php
                                                          $course_rate_res = learn_press_get_course_rate( $post->ID, false );
                                                          $course_rate     = $course_rate_res['rated'];
                                                          $total           = $course_rate_res['total'];
                       
                                                      ?>
                                                      <div class="ratings element-ready-lp-ratings">
                                                      <?php foreach (range(1, 5) as $hnumber): ?>
                                                        <i class="fa fa-star <?php echo esc_attr($hnumber<=$course_rate?'active':'inactive'); ?>"></i>
                                                      <?php endforeach; ?>
                                                        <span><?php echo esc_html($course_rate); ?> (<?php echo sprintf( __( '%s Reviews', 'element-ready-pro' ), $course_rate ); ?>)</span>
                                                      
                                                      </div>
                                                <?php endif; ?>
                                                <div class="course-price element-ready-lp-price">

                                                      <?php if($course->is_free()): ?>
                                                          <?php echo esc_html__('free','element-ready-pro'); ?>
                                                      <?php else: ?>
                                                          
                                                          <?php if( $course->has_sale_price() ): ?> 
                                                            <?php echo $course->get_price_html(); ?> 
                                                          <?php endif; ?>
                                                          <span> <?php echo $course->get_origin_price_html(); ?> </span>  

                                                      <?php endif; ?>

                                                </div>
                                                 <?php 
                                                      $dir          = learn_press_user_profile_picture_upload_dir();
                                                      $user         = get_user_by( 'id', $instructor->get_id());
                                                      $pro_link     = get_user_meta($user->ID,'_lp_profile_picture',true);
                                                      $base_url     = isset($dir['baseurl'])?$dir['baseurl']:'';
                                                      $profile_link = $base_url.'/'.$pro_link;
                        
                                                  ?>
                                                <div class="author">
                                                  <img src="<?php echo esc_url( get_avatar_url( $instructor->get_id() ) ); ?>">
                                                  <?php  echo wp_kses_post($instructor_link) ?>
                                                </div>
                                                <div class="fcf-bottom">
                                                    <a class="element-ready-lp-lesson" href="<?php echo esc_url($course->get_permalink()); ?>"><i class="icon_book_alt"></i><?php echo esc_html($lessons); ?> <?php echo esc_html__('Lessons','element-ready-pro'); ?></a>
                                                    <a class="element-ready-lp-students" href="<?php echo esc_url($course->get_permalink()); ?>"><i class="icon_profile"></i><?php echo esc_html($students_enrolled); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                             <?php endwhile; wp_reset_postdata(); ?>
                       
                    </div>
                </section>
                <!-- Feature Course End -->
            <?php endif; ?>
         <?php
          endif;
         ?>
       <?php

         
      }
  
      
    }
   
    public function course_list(){
      if(!defined('LP_COURSE_CPT')){
        return [];
      }
      $args = array(

        'post_type'   => 'lp_course',
        'orderby' => 'post_date', 
        'order' => 'DESC',
        'post_status'  => 'publish',
        'posts_per_page' => -1
                  
        );  

        $lp_course = get_posts( $args ); 
        $course_list = [];
       
        foreach ($lp_course as $postdata) {
            setup_postdata( $postdata );
            $course_list[$postdata->ID] = [$postdata->post_title];
         
        }
      
        return $course_list;
    }

 

}