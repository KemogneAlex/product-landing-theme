
    <?php  $categories = get_the_category();
        if(! empty( $categories) && $settings['show_cat'] == 'yes' ): ?>
          <div class="binduz-er-meta-category">
            
            <?php if($settings['meta_cat_icon']['library'] !=''): ?>
              <?php \Elementor\Icons_Manager::render_icon( $settings['meta_cat_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php endif; ?>
            
            <?php echo '<a class="element-ready-cat" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>'; ?>
        </div>
    <?php endif; ?>
 