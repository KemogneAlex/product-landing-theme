
    <div class="binduz-post-author">
        <?php if($settings['show_top_author_image'] == 'yes'): ?>
            <?php echo get_avatar( get_the_author_meta( 'ID' ,$post->post_author ), 40 ) ?>
        <?php endif; ?>
       
            <?php if($settings['meta_author_icon']['library'] !=''): ?>
              <?php \Elementor\Icons_Manager::render_icon( $settings['meta_author_icon'], [ 'aria-hidden' => 'true' ] ); ?>
           <?php endif; ?>
     
        <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID', $post->post_author ) ) ); ?>" > <?php echo esc_html(get_the_author_meta( 'display_name', $post->post_author )); ?> </a>
    </div>


